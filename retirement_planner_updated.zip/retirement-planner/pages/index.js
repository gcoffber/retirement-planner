import { useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
} from "chart.js";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip);

export default function RetirementPlanner() {
  const [monthlyIncome, setMonthlyIncome] = useState(3000);
  const [targetAge, setTargetAge] = useState(65);
  const [currentAge, setCurrentAge] = useState(40);
  const [annualReturn, setAnnualReturn] = useState(5);
  const [inflationRate, setInflationRate] = useState(2);
  const [savedSoFar, setSavedSoFar] = useState(125000);
  const [forecastData, setForecastData] = useState(null);

  const calculateForecast = () => {
    const years = targetAge - currentAge;
    const realReturn = ((1 + annualReturn / 100) / (1 + inflationRate / 100)) - 1;
    const annualIncome = monthlyIncome * 12;
    const adjustedIncome = annualIncome * Math.pow(1 + inflationRate / 100, years);
    const totalNeeded = adjustedIncome * 25;
    const yearlySavingTarget = totalNeeded / ((Math.pow(1 + realReturn, years) - 1) / realReturn);

    const labels = Array.from({ length: years + 1 }, (_, i) => currentAge + i);
    const savings = labels.map((_, i) => {
      return Math.floor(yearlySavingTarget * ((Math.pow(1 + realReturn, i + 1) - 1) / realReturn));
    });

    setForecastData({ labels, savings, totalNeeded, yearlySavingTarget });
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif', backgroundColor: '#0f172a', color: 'white', minHeight: '100vh' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold' }}>AI-Powered Retirement Planning</h1>
      <p style={{ marginBottom: '20px' }}>Model each year before you retire, with details of what you need to get in place and how much you need to save.</p>

      <div style={{ marginBottom: '20px' }}>
        <button style={{ backgroundColor: '#14b8a6', color: 'white', padding: '10px', marginRight: '10px' }}>Get Started Now</button>
        <button style={{ border: '1px solid white', padding: '10px', color: 'white' }}>View Demo</button>
      </div>

      <div style={{ display: 'grid', gap: '20px' }}>
        <div style={{ backgroundColor: '#1e293b', padding: '20px', borderRadius: '8px' }}>
          <h2>Inputs</h2>
          <label>Monthly Income Goal (€)</label>
          <input type="number" value={monthlyIncome} onChange={(e) => setMonthlyIncome(+e.target.value)} style={{ width: '100%', marginBottom: '10px' }} />
          <label>Target Retirement Age</label>
          <input type="number" value={targetAge} onChange={(e) => setTargetAge(+e.target.value)} style={{ width: '100%', marginBottom: '10px' }} />
          <label>Your Current Age</label>
          <input type="number" value={currentAge} onChange={(e) => setCurrentAge(+e.target.value)} style={{ width: '100%', marginBottom: '10px' }} />
          <label>Expected Annual Return (%)</label>
          <input type="number" value={annualReturn} onChange={(e) => setAnnualReturn(+e.target.value)} style={{ width: '100%', marginBottom: '10px' }} />
          <label>Inflation Rate (%)</label>
          <input type="number" value={inflationRate} onChange={(e) => setInflationRate(+e.target.value)} style={{ width: '100%', marginBottom: '10px' }} />
          <button onClick={calculateForecast} style={{ backgroundColor: '#14b8a6', color: 'white', width: '100%', padding: '10px' }}>Customize Plan</button>
        </div>

        {forecastData && (
          <div style={{ backgroundColor: '#1e293b', padding: '20px', borderRadius: '8px' }}>
            <h2>Retirement Forecast</h2>
            <Line
              data={{
                labels: forecastData.labels,
                datasets: [{
                  label: "Projected Savings",
                  data: forecastData.savings,
                  borderColor: "#14b8a6",
                  backgroundColor: "#14b8a622",
                }]
              }}
              options={{
                responsive: true,
                scales: {
                  y: { beginAtZero: true }
                }
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}
